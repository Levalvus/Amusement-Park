public class Dark extends Attraction
  {
  //Private Variables
  private int stops;
  private int actors;
  private int scenes;
    
  //Creating Dark Constructor
public Dark(boolean o, int r, double c, double p, String n, double w, double d, int st, int a, int sc) 
  {
    super(o, r, c, p, n, w, d);
    stops = st;
    actors = a;
    scenes = sc;
  }
  //Setter Methods
  public void setSpin(int s)
    {
    stops = s;
    }
  public void setActors(int a)
    {
    actors = a;
    }
  public void setScenes(int s)
    {
    scenes = s;  
    }
    
  //Getter Methods
  public int getStop()
    {
    return stops;
    }
  public int getActors()
    {
    return actors;
    }
  public int getScenes()
    {
    return scenes;
    }

  //ScenesPerMinute method counts the average of how many scenes a dark ride has per minute of it's duration
    public double scenesPerMinute()
    {
      return (scenes/getDuration());
    }

    //ActorsPerScene method counts the average of actors per scene
    public double actorsPerScene()
    {
      return (actors/scenes);
    }
    //StopsPerMinute method counts the average amount of times the ride stops during it's duration.
    public double stopsPerMinute()
    {
      return (stops/getDuration());
    }
  }