public class Show extends Attraction
{
//Creating Private Variables
private int actors;
private boolean loud;
private int crew;
private boolean effects;
private boolean fire;

  //Show Constructor Method
public Show(boolean o, int r, double c, double p, String n, double w, double d, int a, boolean lou, int cr, boolean e, boolean f) 
  {
    super(o, r, c, p, n, w, d);
    actors = a;
    loud = lou;
    crew = cr;
    effects = e;
    fire = f;
  }

  //Setter Methods
  public void setActors(int ac)
  {
  actors = ac;  
  }
  public void setLoud(boolean l)
  {
  loud = l;  
  }
  public void setCrew(int c)
  {
  crew = c;  
  }
  public void setEffects(boolean e)
  {
  effects = e;  
  }
  public void setFire(boolean f)
  {
  fire = f;  
  }
  //Getter Methods
  public int getActors()
  {
   return actors;  
  }
  public boolean getloud()
  {
   return loud;  
  }
  public int getCrew()
  {
   return crew;  
  }
  public boolean getEffects()
  {
   return effects;  
  }
  public boolean getFire()
  {
   return fire;  
  }

  //Intense returns the string "Intense" if it's loud AND has fire OR effects. Otherwise, it will return the string not intense
public String Intense()
  {
    if (loud && (effects || fire))
    {
      return "Intense";
    }
    return "Not Intense";
  }


  //TotalPeople will return the total amount of people invovled in the show
public int totalPeople()
{
  return actors + crew;
}
//TilRestart gets how long the show takes to run, plus 15 minutes to rest the show itself
public double tilNextShow()
  {
    return (getDuration() + 15); 
  }
}