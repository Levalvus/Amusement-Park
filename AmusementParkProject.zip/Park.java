import java.util.*;

public class Park {
//Defining an attractions ArrayList for the Amusement class. This will allow each park to hold a number of atrractions that 
  private ArrayList<Attraction> aList = new ArrayList<Attraction>();

  //Creating other private varibles
  private String name;
  private String address;
  private double totalIncome;

  //Creating the constructor
  public Park(String n, String a)
  {
    name = n;
    address = a;
    totalIncome = findIncome();
  }

  //Getter Methods
  public String getName()
  {
    return name;
  }
  public String getAddress()
  {
    return address;
  }
  public double getIncome()
  {
    return totalIncome;
  }
  //Setter Methods
  public void setName(String na)
  {
    name = na;
  }
  public void setAddress(String ad)
  {
    address = ad;
  }
  //A method to get the total income of the park by getting the income of each ride, and set this income equal to the income of the park to this amount
  public double findIncome()
  {
    double total = 0.0;
    for (Attraction myObject : aList)
      {
        total += myObject.netProfit();
      }
    totalIncome = total;
    return totalIncome;
  }
  //Called in the main class, used to add an attraction to the aList
  public void addAttraction(Attraction b)
    {
      aList.add(b);
    }
  //Removing an attraction from the aList
  public void removeAttraction(Attraction c)
  {
    aList.remove(c);
  }
}