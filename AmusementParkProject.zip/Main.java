class Main {
  public static void main(String[] args) {
    Attraction l = new Attraction(true, 1000, 200.56, 334.21, "TrustFall", 7.36, 1.3);
    System.out.println("Attaction Net Profit: " + l.netProfit());
    System.out.println("Attaction Profit Per Hour: " + l.profitPerRiderPerHour());
Coaster y = new Coaster(true, 1000, 200.56, 334.21, "TrustFall", 7.36, 1.3, true, 3, 57.7);
Coaster v = new Coaster(true, 1000, 200.56, 334.21, "TrustFall", 7.36, 1.3, false, 0, 39.9);
Dark x = new Dark(true, 1000, 200.56, 334.21, "TrustFall", 7.36, 1.3, 5, 2, 10);
Dark p = new Dark(true, 1000, 200.56, 334.21, "TrustFall", 7.36, 1.3, 2, 0, 6);
Show s = new Show(true, 1000, 200.56, 334.21, "TrustFall", 7.36, 25, 7, true, 4, true, false);
    y.setFear();
    System.out.println("Fear For Ride 1: " + y.getFear());
    v.setFear();
    System.out.println("Fear For Ride 2: " + v.getFear());
    System.out.println("Height Requirement For Ride 1: " + y.RecomendedHeight());
    System.out.println("Height Requirement For Ride 2: " + v.RecomendedHeight());
    System.out.println("Loops Per Minute For Ride 1: " + y.LoopsPerMinute());
    System.out.println("Loops Per Minute For Ride 1: " +v.LoopsPerMinute());
    System.out.println("Scenes Per Minute For Dark Ride 1: " + x.scenesPerMinute());
    System.out.println("Actors Per Minute For Dark Ride 2: " + p.actorsPerScene());
    System.out.println("Stops Per Minute For Dark Ride 2: " + p.stopsPerMinute());
    System.out.println("Intensity Of Show: " + s.Intense());
    System.out.println("Number Of People In Show: " + s.totalPeople());
    System.out.println("Minutes Until Next Show: " + s.tilNextShow());
    //Adding A New Park
    Park z = new Park("Seven Poles", "1820 North South Road");
    z.addAttraction(l);
    z.addAttraction(y);
    System.out.println("Income For Park 2: " + z.findIncome());
  }
}