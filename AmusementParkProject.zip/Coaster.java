public class Coaster extends Attraction
{
//Private Variables
private boolean launch;
private int loops;
private double fear;
private double maxSpeed;

//Creating Coaster Constructor
public Coaster(boolean o, int r, double c, double p, String n, double w, double d, boolean la, int lo, double m) 
  {
    super(o, r, c, p, n, w, d);
    launch = la;
    loops = lo;
    fear = 0; 
    maxSpeed = m;
  }

//Setter Methods
  public void setLaunch(boolean l)
  {
  launch = l;
  }
  public void setLoops(int l)
  {
  loops = l;
  }
  public void setFear()
  {
  calculateFear();
  }
  public void setMax(double ms)
  {
  maxSpeed = ms;
  }

//Getter Methods
  public boolean getLaunch()
  {
  return launch;
  }
  public double getLoops()
  {
  return loops;
  }
  public double getFear()
  {
  return fear;
  }
  public double getMax()
  {
  return maxSpeed;
  }

  //CalculateFear Method To Update Fear (From 1 - 10) Method Based On Loops And Launches
  public void calculateFear()
  {
  fear = 0;
  if (launch)
  {
    fear += 2; 
  }
    fear += loops - 1;
    fear += (maxSpeed/10);
    if (fear > 10)
    {
     fear = 10;
    }
  }
  //Recomended Height Gives A Height Recomendation For The Ride Based On It's Factors. The numbers used are based on the height limits at Walt Disney World Parks
  public int RecomendedHeight()
  {
  int height = 35;
  if (launch)
  {
    height += 3;
  }
  if (loops > 0)
  {
    height += 10;
  }
   return height;
  }
  //LoopsPerMinutetakes the duration of the ride and devides it by the number of loops to find how many loops a minute the rider experiences
  public double LoopsPerMinute()
  {
  if (loops == 0)
  {
    return 0;
  }
    return (loops/getDuration());
  }
  
}