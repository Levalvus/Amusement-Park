public class Attraction {
  //Private Variables
  private boolean open;
  private int ridersPerHour;
  private double costToRun;
  private double profit;
  private String name;
  private double wait;
  private double duration;

    //Creating Attraction Constructor
  public Attraction(boolean o, int r, double c, double p, String n, double w, double d) 
  {
    open = o;
    ridersPerHour = r;
    costToRun = c;
    profit = p;
    name = n;
    wait = w;
    duration = d;
  }
  //Setter Methods
  public void setOpen(boolean so)
  {
  open = so;
  }
  public void setRiders(int sr)
  {
  ridersPerHour = sr;
  }
  public void setCost(double sc)
  {
  costToRun = sc;
  }
  public void setProfit(double sp)
  {
  profit = sp;
  }
  public void setName(String sn)
  {
  name = sn;
  }
  public void setWait(double sw)
  {
  wait = sw;
  }
  public void setDuration(double sd)
  {
  duration = sd;
  }
  //Getter Methods
  public boolean getOpen()
  {
  return open;
  }
  public int getRiders()
  {
  return ridersPerHour;
  }
  public double getCost()
  {
  return costToRun;
  }
  public double getProfit()
  {
  return profit;
  }
  public String getName()
  {
  return name;
  }
  public double getWait()
  {
  return wait;
  }
  public double getDuration()
  {
  return duration;
  }
  //Returning Overall Profit Of An Attraction
  public double netProfit()
  {
  return (profit - costToRun);    
  }
  //Returning The Average Profit Per Rider Per Hour
  public double profitPerRiderPerHour()
  {
  return (netProfit()/ridersPerHour);
  }
}